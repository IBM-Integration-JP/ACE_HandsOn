# Microsoft Developer Studio Project File - Name="mqput2" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Console Application" 0x0103

CFG=mqput2 - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "mqput2.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "mqput2.mak" CFG="mqput2 - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "mqput2 - Win32 Release" (based on "Win32 (x86) Console Application")
!MESSAGE "mqput2 - Win32 Debug" (based on "Win32 (x86) Console Application")
!MESSAGE "mqput2 - Win32 Local Server" (based on "Win32 (x86) Console Application")
!MESSAGE "mqput2 - Win32 Client" (based on "Win32 (x86) Console Application")
!MESSAGE "mqput2 - Win32 Put2 Client" (based on "Win32 (x86) Console Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "mqput2 - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /W3 /GX /O2 /I "C:\MQ7\tools\c\include" /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD BASE RSC /l 0x409 /d "NDEBUG"
# ADD RSC /l 0x409 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386
# ADD LINK32 kernel32.lib "c:\MQ7\tools\lib\mqm.lib" /nologo /subsystem:console /machine:I386

!ELSEIF  "$(CFG)" == "mqput2 - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /GZ /c
# ADD CPP /nologo /W3 /Gm /GX /ZI /Od /I "C:\MQ7\tools\c\include" /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /D "NOTUNE" /YX /FD /GZ /c
# ADD BASE RSC /l 0x409 /d "_DEBUG"
# ADD RSC /l 0x409 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /pdbtype:sept
# ADD LINK32 kernel32.lib advapi32.lib "c:\MQ7\tools\lib\mqm.lib" /nologo /subsystem:console /debug /machine:I386 /pdbtype:sept
# SUBTRACT LINK32 /pdb:none

!ELSEIF  "$(CFG)" == "mqput2 - Win32 Local Server"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Local Server"
# PROP BASE Intermediate_Dir "Local Server"
# PROP BASE Ignore_Export_Lib 0
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Local Server"
# PROP Intermediate_Dir "Local Server"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /W3 /GX /O2 /I "C:\MQ7\tools\c\include" /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "NOTUNE" /YX /FD /c
# ADD BASE RSC /l 0x409 /d "NDEBUG"
# ADD RSC /l 0x409 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib "c:\program files\mqseries\tools\lib\mqm.lib" /nologo /subsystem:console /machine:I386
# ADD LINK32 kernel32.lib advapi32.lib "c:\MQ7\tools\lib\mqm.lib" /nologo /subsystem:console /machine:I386 /out:"Release/mqputs.exe"

!ELSEIF  "$(CFG)" == "mqput2 - Win32 Client"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Client"
# PROP BASE Intermediate_Dir "Client"
# PROP BASE Ignore_Export_Lib 0
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Client"
# PROP Intermediate_Dir "Client"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "NOTUNE" /YX /FD /c
# ADD CPP /nologo /W3 /GX /O2 /I "C:\MQ7\tools\c\include" /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "NOTUNE" /D "MQCLIENT" /YX /FD /c
# ADD BASE RSC /l 0x409 /d "NDEBUG"
# ADD RSC /l 0x409 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib "c:\program files\mqseries\tools\lib\mqm.lib" /nologo /subsystem:console /machine:I386 /out:"Local Server/mqputs.exe"
# ADD LINK32 kernel32.lib "c:\MQ7\tools\lib\MQIC32.LIB" /nologo /subsystem:console /machine:I386 /out:"Release/mqputsc.exe"

!ELSEIF  "$(CFG)" == "mqput2 - Win32 Put2 Client"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "mqput2___Win32_Put2_Client"
# PROP BASE Intermediate_Dir "mqput2___Win32_Put2_Client"
# PROP BASE Ignore_Export_Lib 0
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Put2_Client"
# PROP Intermediate_Dir "Put2_Client"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /I "C:\MQ7\tools\c\include" /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "NOTUNE" /D "MQCLIENT" /YX /FD /c
# ADD CPP /nologo /W3 /GX /O2 /I "C:\MQ7\tools\c\include" /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "MQCLIENT" /YX /FD /c
# ADD BASE RSC /l 0x409 /d "NDEBUG"
# ADD RSC /l 0x409 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib "c:\MQ7\tools\lib\MQIC32.LIB" /nologo /subsystem:console /machine:I386 /out:"Release/mqputsc.exe"
# ADD LINK32 kernel32.lib "c:\MQ7\tools\lib\MQIC32.LIB" /nologo /subsystem:console /machine:I386 /out:"Client/mqput2c.exe"

!ENDIF 

# Begin Target

# Name "mqput2 - Win32 Release"
# Name "mqput2 - Win32 Debug"
# Name "mqput2 - Win32 Local Server"
# Name "mqput2 - Win32 Client"
# Name "mqput2 - Win32 Put2 Client"
# Begin Group "Source Files"

# PROP Default_Filter "*.c"
# Begin Source File

SOURCE=.\comsubs.c
# End Source File
# Begin Source File

SOURCE=.\mqput2.c
# End Source File
# Begin Source File

SOURCE=.\parmline.c
# End Source File
# Begin Source File

SOURCE=.\putparms.c
# End Source File
# Begin Source File

SOURCE=.\qsubs.c
# End Source File
# Begin Source File

SOURCE=.\rfhsubs.c
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "*.h"
# Begin Source File

SOURCE=.\comsubs.h
# End Source File
# Begin Source File

SOURCE=.\int64defs.h
# End Source File
# Begin Source File

SOURCE=.\parmline.h
# End Source File
# Begin Source File

SOURCE=.\putparms.h
# End Source File
# Begin Source File

SOURCE=.\qsubs.h
# End Source File
# Begin Source File

SOURCE=.\rfhsubs.h
# End Source File
# End Group
# End Target
# End Project
