/********************************************************************/
/*                                                                  */
/*   putparms.h - Input parameter file processing subroutines       */
/*                                                                  */
/********************************************************************/

/* includes for MQI */
#include <cmqc.h>
#include "parmline.h"

#define INIT_COUNT	32			/* number of messages written initially */
#define MIN_SLEEP	1			/* 1 millisecond */
#define MAX_SLEEP	10000		/* 10 seconds */
#define DEF_SLEEP	1			/* Default sleep time (10 milliseconds) */
#define MIN_THINK	1			/* 1 millisecond */
#define MAX_THINK	30000		/* 30 seconds */

typedef struct {
	void*	nextfile;
	char	*dataptr;
	void	*mqmdptr;
	char	*userDataPtr;
	int		rfhlen;
	int		length;
	int		hasMQMD;
	int		hasRFH;
	int		useFileRFH;
	int		newMsgId;
	int		Codepage;
	int		Encoding;
	int		Expiry;
	int		Persist;
	int		Priority;
	int		Report;
	int		Msgtype;
	int		Feedback;
	int		GetByCorrelId;			/* used by MQLatency */
	int		CorrelIdSet;
	int		GroupIdSet;
	int		AcctTokenSet;
	int		inGroup;
	int		lastGroup;
	int		FormatSet;
	int		setTimeStamp;
#ifdef WIN32
	DWORD	thinkTime;
#else
	int		thinkTime;
#endif
	char	*acqStorAddr;
	char	CorrelId[MQ_CORREL_ID_LENGTH + 1];
	char	GroupId[MQ_GROUP_ID_LENGTH + 1];
	char	Format[MQ_FORMAT_LENGTH + 1];
	char	ReplyQ[MQ_Q_NAME_LENGTH + 1];
	char	ReplyQM[MQ_Q_MGR_NAME_LENGTH + 1];
	char	UserId[MQ_USER_ID_LENGTH + 1];
	char	AccountingToken[MQ_ACCOUNTING_TOKEN_LENGTH];
}	FILEPTR;

FILEPTR * processParmFile(char * parmFileName, putParms * parms);
int readFileData(const char *filename, int *length, char ** dataptr, putParms * parms);
char * scanForDelim(char * msgdata, const int datalen, putParms *parms);
