-- 1) INSERT（Create）用トリガ関数
CREATE OR REPLACE FUNCTION myschema.trg_staff_create_fn()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO myschema.staff_event (object_key, object_verb)
    VALUES (NEW.staffnum, 'Create');
    RETURN NEW;
END;
$$;

-- 2) DELETE 用トリガ関数
CREATE OR REPLACE FUNCTION myschema.trg_staff_delete_fn()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO myschema.staff_event (object_key, object_verb)
    VALUES (OLD.staffnum, 'Delete');
    RETURN OLD;
END;
$$;

-- 3) UPDATE 用トリガ関数
CREATE OR REPLACE FUNCTION myschema.trg_staff_update_fn()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO myschema.staff_event (object_key, object_verb)
    VALUES (NEW.staffnum, 'Update');
    RETURN NEW;
END;
$$;

-- === TRIGGER 本体 ===
-- AFTER INSERT
CREATE TRIGGER staff_create
AFTER INSERT ON myschema.staff
FOR EACH ROW
EXECUTE FUNCTION myschema.trg_staff_create_fn();

-- AFTER DELETE
CREATE TRIGGER staff_delete
AFTER DELETE ON myschema.staff
FOR EACH ROW
EXECUTE FUNCTION myschema.trg_staff_delete_fn();

-- AFTER UPDATE
CREATE TRIGGER staff_update
AFTER UPDATE ON myschema.staff
FOR EACH ROW
EXECUTE FUNCTION myschema.trg_staff_update_fn();