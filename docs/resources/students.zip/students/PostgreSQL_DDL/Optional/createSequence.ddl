CREATE SEQUENCE myschema.staff_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    MINVALUE 1
    NO MAXVALUE
    NO CYCLE
    CACHE 1;

CREATE PROCEDURE myschema.generate_staff_id(OUT staff_seq integer)
LANGUAGE plpgsql
AS $$
BEGIN
    staff_seq := nextval('myschema.staff_seq');
END;
$$;