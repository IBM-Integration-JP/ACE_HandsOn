CREATE TABLE myschema.staff_event (
    event_id integer NOT NULL
        GENERATED ALWAYS AS IDENTITY (
            START WITH 1
            INCREMENT BY 1
            MINVALUE 1
            MAXVALUE 2147483647
            NO CYCLE
            CACHE 1
        ),
    object_key  varchar(10) NOT NULL,
    object_verb varchar(10) NOT NULL
);

ALTER TABLE myschema.staff_event 
    ADD CONSTRAINT event_pk PRIMARY KEY (event_id);
