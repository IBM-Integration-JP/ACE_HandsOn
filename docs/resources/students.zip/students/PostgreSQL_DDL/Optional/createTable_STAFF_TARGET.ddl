CREATE TABLE myschema.staff_target (
    staffid     varchar(10)  NOT NULL,
    lastchange  date,
    staffname   varchar(80),
    mail        varchar(100)
);

ALTER TABLE myschema.staff_target 
    ADD CONSTRAINT staff_target_pk PRIMARY KEY (staffid);