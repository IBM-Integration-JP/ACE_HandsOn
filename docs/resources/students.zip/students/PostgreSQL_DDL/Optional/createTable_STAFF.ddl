CREATE TABLE myschema.staff (
    staffnum    varchar(10)  NOT NULL,
    lastchange  date,
    firstname   varchar(30),
    lastname    varchar(30),
    mail        varchar(100)
);

ALTER TABLE myschema.staff 
    ADD CONSTRAINT staff_pk PRIMARY KEY (staffnum);