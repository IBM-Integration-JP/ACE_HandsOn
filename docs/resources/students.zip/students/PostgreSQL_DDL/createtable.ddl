CREATE SCHEMA myschema;

CREATE TABLE myschema.aftersales (
    sonum    CHAR(5) NOT NULL,
    customer CHAR(5),
    year     CHAR(4),
    month    CHAR(2),
    day      CHAR(2)
);

CREATE TABLE myschema.beforesales (
    sonum    CHAR(5) NOT NULL,
    customer CHAR(5),
    gendate  DATE
);

CREATE TABLE myschema.codemaster (
    beforecode CHAR(5) NOT NULL,
    aftercode  CHAR(5)
);

ALTER TABLE myschema.aftersales
  ADD CONSTRAINT aftersales_pk PRIMARY KEY (sonum);

ALTER TABLE myschema.beforesales
  ADD CONSTRAINT beforesales_pk PRIMARY KEY (sonum);

ALTER TABLE myschema.codemaster
  ADD CONSTRAINT codemaster_pk PRIMARY KEY (beforecode);