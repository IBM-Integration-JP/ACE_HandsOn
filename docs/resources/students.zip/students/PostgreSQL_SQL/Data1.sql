INSERT INTO myschema.beforesales (sonum, customer, gendate) VALUES ('0001', 'AAA', '2012-04-01');
INSERT INTO myschema.beforesales (sonum, customer, gendate) VALUES ('0005', 'BBB', '2012-04-03');
INSERT INTO myschema.beforesales (sonum, customer, gendate) VALUES ('0006', 'CCC', '2012-05-03');
INSERT INTO myschema.beforesales (sonum, customer, gendate) VALUES ('0099', 'DDD', '2013-01-01');