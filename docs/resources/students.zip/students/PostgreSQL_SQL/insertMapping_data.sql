INSERT INTO myschema.codemaster (beforecode, aftercode) VALUES ('A001', '001');
INSERT INTO myschema.codemaster (beforecode, aftercode) VALUES ('A002', '002');
INSERT INTO myschema.codemaster (beforecode, aftercode) VALUES ('A003', '003');
INSERT INTO myschema.codemaster (beforecode, aftercode) VALUES ('A011', '011');
INSERT INTO myschema.codemaster (beforecode, aftercode) VALUES ('A012', '012');
